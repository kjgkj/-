package com.xhu.web.dao;

import com.xhu.web.po.Book;
import com.xhu.web.po.Borrow;
import com.xhu.web.utils.JDBCUtils;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class BorrowDaoImpl implements BorrowDao{
    @Override
    public List<Borrow> selectAllBorrow() {
        Connection conn=null;
        PreparedStatement ps=null;
        ResultSet rs=null;
        String sql="select * from borrow";
        List<Borrow> borrows=new ArrayList<>();
        try {
            conn= JDBCUtils.getConnection();
            ps=conn.prepareStatement(sql);
            Borrow borrow=null;
            rs=ps.executeQuery();
            while(rs.next()){
                borrow=new Borrow();
                borrow.setBookID(rs.getString(2));
                borrow.setReaderID(rs.getString(1));
                borrow.setBorrowTime(rs.getDate(3));
                borrow.setReturnTime(rs.getDate(4));
                borrows.add(borrow);
            }
        } catch (SQLException e1) {
            e1.printStackTrace();
        }finally{
            JDBCUtils.close(conn, ps,rs);
        }
        return borrows;
    }

    @Override
    public void borrowbook(Borrow borrow) {
        Connection conn = null;
        PreparedStatement ps = null;
        String sql = "insert into Borrow(ReaderID,BookID,BorrowTime,Returntime)values (?,?,?,?)";//占位符
        try {
            //1.获取连接对象
            conn = JDBCUtils.getConnection();
            //2.预编译sql语句，返回PreparedStatement的实例
            ps = conn.prepareStatement(sql);
            //3.填充占位符
            ps.setString(1, borrow.getReaderID());
            ps.setString(2, borrow.getBookID());
            ps.setDate(3,borrow.getBorrowTime());
            ps.setDate(4, borrow.getReturnTime());
            //4.执行
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            try {
                throw new SQLException("添加数据失败");
            } catch (SQLException e2) {
                e2.printStackTrace();
            }
        } finally {
            JDBCUtils.close(conn, ps, null);
        }
    }

    @Override
   public List<Borrow> selectReaderBorrow(String ReaderID){
        Connection conn=null;
        PreparedStatement ps=null;
        ResultSet rs=null;
        String sql="select * from borrow where ReaderID=?";
        List<Borrow> borrows=new ArrayList<>();
        try {
            conn= JDBCUtils.getConnection();
            ps=conn.prepareStatement(sql);
            Borrow borrow=null;
            ps.setString(1, ReaderID);
            rs=ps.executeQuery();
            while(rs.next()){
                borrow=new Borrow();
                borrow.setReaderID(rs.getString(1));
                borrow.setBookID(rs.getString(2));
                borrow.setBorrowTime(rs.getDate(3));
                borrow.setReturnTime(rs.getDate(4));
                borrows.add(borrow);
            }
        } catch (SQLException e1) {
            e1.printStackTrace();
        }finally{
            JDBCUtils.close(conn, ps,rs);
        }
        return borrows;
    }

    @Override
    public void deletebook(String BookID) {
        Connection conn=null;
        PreparedStatement ps=null;
        ResultSet rs=null;
        String sql="delete from borrow where BookID=?";
        try{
            conn=JDBCUtils.getConnection();
            ps=conn.prepareStatement(sql);
            ps.setString(1,BookID);
            ps.executeUpdate();
        }catch(SQLException e){
            e.printStackTrace();
            try{
                throw  new SQLException("添加数据失败");
            }catch (SQLException e2){
                e2.printStackTrace();
            }
            finally {
                JDBCUtils.close(conn,ps,rs);
            }
        }
    }
}
