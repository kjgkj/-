package com.xhu.web.servlet;

import com.xhu.web.dao.BookDao;
import com.xhu.web.dao.BookDaoImpl;
import com.xhu.web.dao.BorrowDao;
import com.xhu.web.dao.BorrowDaoImpl;
import com.xhu.web.po.Book;
import com.xhu.web.po.Borrow;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.util.List;

@WebServlet("/AdminBorrowListServlet")
public class AdminBorrowListServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request,response);

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        BorrowDao dao=new BorrowDaoImpl();
        List<Borrow> borrowList=dao.selectAllBorrow();
        request.setAttribute("borrowList",borrowList);
        request.getRequestDispatcher("AdminBorrowList.jsp").forward(request,response);

    }
}
