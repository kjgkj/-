package com.xhu.web.po;

public class Admin {
    private String AdminID;
    private String AdminPassowrd;

    public Admin() {
        super();
    }

    public String getAdminID() {
        return AdminID;
    }

    public void setAdminID(String adminID) {
        AdminID = adminID;
    }

    public String getAdminPassowrd() {
        return AdminPassowrd;
    }

    public void setAdminPassowrd(String adminPassowrd) {
        AdminPassowrd = adminPassowrd;
    }

    @Override
    public String toString() {
        return "Admin{" +
                "AdminID='" + AdminID + '\'' +
                ", AdminPassowrd='" + AdminPassowrd + '\'' +
                '}';
    }
}
