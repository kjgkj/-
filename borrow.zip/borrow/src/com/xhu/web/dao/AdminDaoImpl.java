package com.xhu.web.dao;

import com.xhu.web.po.Admin;
import com.xhu.web.po.Reader;
import com.xhu.web.utils.JDBCUtils;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class AdminDaoImpl implements AdminDao {
    @Override
    public Admin selectAdminByID(String AdminID) {
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        Admin admin=new Admin();
        String sql = "select AdminID,AdminPassword  from admin  where AdminID=?";//占位符
        try {
            conn = JDBCUtils.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setString(1, AdminID);
            rs = ps.executeQuery();
            if (rs.next()) {
                admin.setAdminID(rs.getNString(1));
                admin.setAdminPassowrd(rs.getNString(2));
            }

        } catch (SQLException e) {
            e.printStackTrace();
            try {
                throw new SQLException("查询失败");
            } catch (SQLException e2) {
                e2.printStackTrace();
            } finally {
                JDBCUtils.close(null, ps, rs);
            }

        }
        return admin;

    }
}
