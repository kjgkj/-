package com.xhu.web.dao;

import com.xhu.web.po.Book;
import com.xhu.web.po.Borrow;

import java.util.List;

public interface BorrowDao {
    List<Borrow> selectAllBorrow();
    void borrowbook(Borrow borrow);
    List<Borrow> selectReaderBorrow(String ReaderID);
    void deletebook(String BookID);

}
