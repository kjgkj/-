package com.xhu.web.service;

import com.xhu.web.dao.ReaderDao;
import com.xhu.web.dao.ReaderDaoImpl;
import com.xhu.web.po.Reader;

public class ReaderServiceImpl implements ReaderService{
    private ReaderDao dao=new ReaderDaoImpl();
    @Override
    public Reader querypwd( String ReaderID) {
        Reader reader=dao.selectpwd(ReaderID);
        return reader;
    }
}
