import tkinter as tk
from tkinter import filedialog
import tkinter.font as tkFont
from recognizetime import TimeGet


class App:
    def __init__(self, root):
        # setting title
        root.title("undefined")
        # setting window size
        file_path= None
        width = 682
        height = 261
        screenwidth = root.winfo_screenwidth()
        screenheight = root.winfo_screenheight()
        alignstr = '%dx%d+%d+%d' % (width, height, (screenwidth - width) / 2, (screenheight - height) / 2)
        root.geometry(alignstr)
        root.resizable(width=False, height=False)

        self.GLineEdit_334 = tk.Entry(root)
        self.GLineEdit_334["borderwidth"] = "1px"
        ft = tkFont.Font(family='Times', size=10)
        self.GLineEdit_334["font"] = ft
        self.GLineEdit_334["fg"] = "#333333"
        self.GLineEdit_334["justify"] = "center"
        self.GLineEdit_334["text"] = "xuan"
        self.GLineEdit_334.place(x=30, y=120, width=488, height=53)

        self.GButton_293 = tk.Button(root)
        self.GButton_293["bg"] = "#5fb878"
        ft = tkFont.Font(family='Times', size=18)
        self.GButton_293["font"] = ft
        self.GButton_293["fg"] = "#fefffe"
        self.GButton_293["justify"] = "center"
        self.GButton_293["text"] = "选图片"
        self.GButton_293["relief"] = "flat"
        self.GButton_293.place(x=530, y=120, width=100, height=51)
        self.GButton_293["command"] = self.GButton_293_command

        GLabel_135 = tk.Label(root)
        ft = tkFont.Font(family='Times', size=53)
        GLabel_135["font"] = ft
        GLabel_135["fg"] = "#5fb878"
        GLabel_135["justify"] = "center"
        GLabel_135["text"] = "识别时间"
        GLabel_135.place(x=120, y=10, width=409, height=73)

        GButton_715 = tk.Button(root)
        GButton_715["bg"] = "#ff7800"
        ft = tkFont.Font(family='Times', size=28)
        GButton_715["font"] = ft
        GButton_715["fg"] = "#ffffff"
        GButton_715["justify"] = "center"
        GButton_715["text"] = "识别时间"
        GButton_715.place(x=190, y=190, width=294, height=51)
        GButton_715["command"] = self.GButton_715_command

    # 设置界面按键--图片选择
    def GButton_293_command(self):
        self.file_path = filedialog.askopenfilename(title="Select Picture", filetypes=(("Image files", "*.jpg;*.jpeg;*.png"),))

        if self.file_path:
            self.GLineEdit_334.delete(0, tk.END)  # Clear the entry field
            self.GLineEdit_334.insert(0, self.file_path)  # Insert the file path

    # 设置界面按键--时间识别
    def GButton_715_command(self):
        if self.file_path:
            try:
                TimeGet(self.file_path)
            except Exception as e:
                pass

if __name__ == "__main__":
    root = tk.Tk()
    app = App(root)
    root.mainloop()
