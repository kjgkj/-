package com.xhu.web.dao;
import com.xhu.web.po.Book;
import com.xhu.web.utils.JDBCUtils;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class BookDaoImpl implements BookDao {
    @Override
    public void insert(Book book) {
        Connection conn = null;
        PreparedStatement ps = null;
        String sql = "insert into Book(BookID, BookName,BookType,Author,PublisherID, Price,BookSum,Stock) values (?,?,?,?,?,?,?,?)";//占位符
        try {
            //1.获取连接对象
            conn = JDBCUtils.getConnection();
            //2.预编译sql语句，返回PreparedStatement的实例
            ps = conn.prepareStatement(sql);
            //3.填充占位符
            ps.setString(1, book.getBookID());
            ps.setString(2, book.getBookName());
            ps.setString(3, book.getBookType());
            ps.setString(4, book.getAuthor());
            ps.setString(5, book.getPublisherID());
            ps.setInt(6, book.getPrice());
            ps.setInt(7, book.getBookSum());
            ps.setInt(8, book.getBookSum());
            //4.执行
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            try {
                throw new SQLException("添加数据失败");
            } catch (SQLException e2) {
                e2.printStackTrace();
            }
        }
        finally {
            JDBCUtils.close(conn, ps, null);
        }
    }

    @Override
    public void update(Book book) {
        Connection conn=null;
        PreparedStatement ps=null;
        ResultSet rs=null;
        String sql="update book set BookName=?,BookType=?,Author=?,PublisherID=?,Price=?,BookSum=?,Stock=? where BookID=?";
        try{
            conn=JDBCUtils.getConnection();
            ps=conn.prepareStatement(sql);
            ps.setString(1,book.getBookName());
            ps.setString(2,book.getBookType());
            ps.setString(3,book.getAuthor());
            ps.setString(4,book.getPublisherID());
            ps.setInt(5,book.getPrice());
            ps.setInt(6,book.getBookSum());
            ps.setInt(7,book.getStock());
            ps.setString(8, book.getBookID());
            ps.executeUpdate();
        }catch (SQLException e){
            e.printStackTrace();
            try{
                throw new SQLException("修改数据失败");
            }catch (SQLException e2){
                e2.printStackTrace();
            }finally {
                JDBCUtils.close(conn,ps,rs);
            }
        }
    }

    @Override
    public void delete(String BookID) {
        Connection conn=null;
        PreparedStatement ps=null;
        ResultSet rs=null;
        String sql="delete from book where BookID=?";
        try{
            conn=JDBCUtils.getConnection();
            ps=conn.prepareStatement(sql);
            ps.setString(1,BookID);
            ps.executeUpdate();
        }catch(SQLException e){
            e.printStackTrace();
            try{
                throw  new SQLException("添加数据失败");
            }catch (SQLException e2){
                e2.printStackTrace();
            }
            finally {
                JDBCUtils.close(conn,ps,rs);
            }
        }
    }

    @Override
    public List<Book> selectAll() {
        Connection conn=null;
        PreparedStatement ps=null;
        ResultSet rs=null;
        String sql="select * from book ";
        List<Book> books=new ArrayList<>();
        try {
            conn=JDBCUtils.getConnection();
            ps=conn.prepareStatement(sql);
            Book book=null;
            rs=ps.executeQuery();
            while(rs.next()){
                book=new Book();
               book.setBookID(rs.getString(1));
               book.setBookName(rs.getString(2));
               book.setBookType(rs.getString(3));
               book.setAuthor(rs.getString(4));
               book.setPublisherID(rs.getString(5));
               book.setPrice(rs.getInt(6));
               book.setBookSum(rs.getInt(7));
               book.setStock(rs.getInt(8));
               books.add(book);
            }
        } catch (SQLException e1) {
            e1.printStackTrace();
        }finally{
            JDBCUtils.close(conn, ps,rs);
        }
        return books;
    }

    @Override
    public Book selectByID(String BookID) {
        Connection conn = null;
        PreparedStatement  ps=null;
        ResultSet rs = null;
        Book book = null;
        String sql="select * from book where BookID=?";//占位符
        try {
            //1.获取连接对象
            conn = JDBCUtils.getConnection();
            //2.预编译sql语句，返回PreparedStatement的实例
            ps=conn.prepareStatement(sql);
            //3.填充占位符
            ps.setString(1, BookID);
            //4.执行
            rs = ps.executeQuery();
            if(rs.next()){
                book=new Book();
                String BookName= rs.getString(2);
                String BookType=rs.getString(3);
                String Author=rs.getString(4);
                String Publisher=rs.getString(5);
                int Price=rs.getInt(6);
                int BookSum=rs.getInt(7);
                int Stock=rs.getInt(8);
                book.setBookID(rs.getString(1));
                book.setBookName(rs.getString(2));
                book.setBookType(rs.getString(3));
                book.setAuthor(rs.getString(4));
                book.setPublisherID(rs.getString(5));
                book.setPrice(rs.getInt(6));
                book.setBookSum(rs.getInt(7));
                book.setStock(rs.getInt(8));
            }
        } catch (SQLException e) {
            e.printStackTrace();
            try {
                throw new SQLException("根据id查询失败");
            } catch (SQLException e2) {
                e2.printStackTrace();
            }
        }finally {
            JDBCUtils.close(conn, ps, rs);
        }
        return book;

    }
}

