package com.xhu.web.service;

import com.xhu.web.po.Reader;
import org.apache.el.stream.StreamELResolverImpl;

public interface ReaderService {
    Reader querypwd(String ReaderID);
}
