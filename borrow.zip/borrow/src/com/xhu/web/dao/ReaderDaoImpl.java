package com.xhu.web.dao;

import com.xhu.web.po.Reader;
import com.xhu.web.utils.JDBCUtils;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ReaderDaoImpl implements ReaderDao{
    @Override
    public Reader selectpwd(String ReaderID) {
        Connection conn = null;
                PreparedStatement ps = null;
                ResultSet rs = null;
                Reader reader =new Reader();;
                String sql = "select ReaderID,ReaderPassword,ReaderName  from reader  where ReaderID=?";//占位符
                try {
                    conn = JDBCUtils.getConnection();
                    ps = conn.prepareStatement(sql);
                    ps.setString(1, ReaderID);
                    rs = ps.executeQuery();
                    if (rs.next()) {
                        reader.setReaderID(rs.getNString(1));
                        reader.setReaderPassword(rs.getNString(2));
                        reader.setReaderName(rs.getNString(3));
                    }

                } catch (SQLException e) {
                    e.printStackTrace();
                    try {
                        throw new SQLException("查询失败");
                    } catch (SQLException e2) {
                        e2.printStackTrace();
                    } finally {
                        JDBCUtils.close(null, ps, rs);
            }

        }
        return reader;
    }
}
