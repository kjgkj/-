package com.xhu.web.service;

import com.xhu.web.po.Admin;

public interface AdminService {
    Admin Adminquerypwd(String AdminID);
}
