package com.xhu.web.service;

import com.xhu.web.dao.BorrowDao;
import com.xhu.web.dao.BorrowDaoImpl;
import com.xhu.web.po.Borrow;

import java.util.List;

public class BorrowServiceImpl implements BorrowService {
    private BorrowDao dao1=new BorrowDaoImpl();
    public void ReaderBorrowBook(Borrow borrow) {
        dao1.borrowbook(borrow);
    }

    @Override
    public List<Borrow> BorrowBook(String ReaderID) {
        List<Borrow> borrows=dao1.selectReaderBorrow(ReaderID);
        return borrows;
    }

    @Override
    public void ReturnBook(String BookID) {
        dao1.deletebook(BookID);
    }
}
