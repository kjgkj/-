package com.xhu.web.service;

import com.xhu.web.dao.AdminDao;
import com.xhu.web.dao.AdminDaoImpl;
import com.xhu.web.po.Admin;

public class AdminServiceImpl implements AdminService{
    private AdminDao dao=new AdminDaoImpl();

    @Override
    public Admin Adminquerypwd(String AdminID) {
        Admin admin=dao.selectAdminByID(AdminID);
        return admin;
    }
}
