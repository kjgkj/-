import imutils
from imutils.perspective import four_point_transform
from imutils import contours
import matplotlib.pyplot as plt
import easyocr
import cv2
import numpy as np

def TimeGet(imgg):
	img = cv2.imread(imgg)


	bilateral_filtered_image = cv2.bilateralFilter(img, 5, 175, 175)
	edge_detected_image = cv2.Canny(bilateral_filtered_image, 10,240)
	circle = cv2.HoughCircles(edge_detected_image, cv2.HOUGH_GRADIENT, 1, 600, param1=200, param2=30, minRadius=0, maxRadius=0)
	circles = np.uint16(np.round(circle))

	for i in circles[0, :]:
		cv2.circle(img, (i[0], i[1]), i[2], (0, 255, 0), 2)
		location = [[i[0], i[1]], i[2]]
		print(location)
		break

	mask = np.zeros_like(img)

	cv2.circle(mask, (location[0][0], location[0][1]), location[1], (255, 255, 255), -1)

	masked_image = cv2.bitwise_and(img, mask)

#将区域裁剪出来
	height, width = masked_image.shape[:2]

	x = width // 4
	y = height // 4
	crop_width = width // 2
	crop_height = height // 2

	cropped_img = masked_image[y:y+crop_height, x:x+crop_width]


	height, width = cropped_img.shape[:2]

	y = height // 4
	crop_height = height // 2


	cropped_img = cropped_img[y:y+crop_height,:]

	line1_h = 0
	line2_h = 0

	gray = cv2.cvtColor(cropped_img ,cv2.COLOR_BGR2GRAY)
	height_g, width_g = gray.shape
	blurred = cv2.GaussianBlur(gray,(5,5),0 )
	edged  = cv2.Canny(gray,50,200,255)

	# 高斯滤波
	# cv2.GaussianBlur(gray, (5, 5), 0)
	# 查看灰度图效果
	# plt.imshow(gray)
	# plt.show()

	#将白色背景的数据改成黑色背景数据
	num_bg=0
	for y in range(height_g):
		for x in range(width_g):
			if gray[y, x]<100 :
				num_bg=num_bg+1
	print("black:",num_bg)
	print("all:", height_g*width_g)
	# 如果黑色数据小于总像素个数的40%则进行黑白转换
	if(num_bg < height_g*width_g*0.4):
		for y in range(height_g):
			for x in range(width_g):
				# 对像素值小于100的部分，颜色暗一点的转换为白色
				if gray[y, x] < 100:
					gray[y, x]=255
				# 对像素值大于100的部分，颜色暗一点的转换为白色
				if gray[y, x] > 100 and gray[y, x]!=255:
					gray[y, x]=0

	# plt.imshow(gray)
	# plt.show()
	kernel = np.ones((3, 3), np.uint8)

	thresh = cv2.threshold(gray, 10, 255,cv2.THRESH_BINARY_INV | cv2.THRESH_OTSU)[1]
	thresh=cv2.dilate(thresh, kernel, iterations=1)
	thresh = cv2.erode(thresh, kernel, iterations=3)
	kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 11))
	# thresh1 = cv2.morphologyEx(thresh, cv2.MORPH_OPEN, kernel)

	thresh2 = cv2.threshold(thresh, 240, 255,cv2.THRESH_BINARY_INV | cv2.THRESH_OTSU)[1]
	kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (10,1))
	thresh3 = cv2.morphologyEx(thresh2, cv2.MORPH_OPEN, kernel)

	# 腐蚀膨胀，去除数字边缘的背景数据，可以调试iterations来优化检测效果
	# 腐蚀操作，可以让数字变瘦，让部分背景变成0，用于清理部分小数据的干扰
	dilated = cv2.erode(thresh3.copy(), None, iterations=5)
	# 膨胀操作，让之前瘦的图片变胖，可以在下面检测的时候生成比较好的检测框
	dilated = cv2.dilate(dilated, None, iterations=7)

	dilated_1 = cv2.dilate(thresh3.copy(), None, iterations=2)
	#分割部分--第一次检测目标框，获取大概的目标位置
	contours, hierarchy = cv2.findContours(dilated, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
	contours_1, hierarchy_1 = cv2.findContours(dilated_1, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
	#找到前四个最大的矩形框
	# 初始化参数
	max_area=0
	area1=0
	area2=0
	area3=0
	area4=0
	width=0
	height=0
	x=0
	y=0
	#1 获取最大的目标框-----下面2，3，4的目标获取都是用相同方式
	for i in range(len(contours)):
		areax = cv2.contourArea(contours[i])
		# 去除过大和过小的目标
		if areax <2000 or  areax >8000:
			continue
		# 获取目标的框
		rect = cv2.minAreaRect(contours[i])
		# 获取目标框的长宽
		width = rect[1][0]
		height = rect[1][1]
		# 去除误检数据
		# 去除过大目标，接近全局的框
		if width> width_g*0.9 or height> height_g*0.9:
			continue
		# 去除接近方形的目标，正常目标为长方形
		if width>height and width/height <1.2 :
			continue
		if width<height and height/width <1.2:
			continue
		# 去除过小的目标框
		if width<10 or height<10:
			continue
		# 获得最大的目标数据，并记录编号i赋值给area1，后面检测需要
		if width > max_area:
			max_area=width
			area1=i
	max_area = 0
	width = 0
	height = 0

	# 2 获取第二大的目标框
	for i in range(len(contours)):
		areax = cv2.contourArea(contours[i])
		if areax <2000 or  areax >8000:
			continue
		rect = cv2.minAreaRect(contours[i])
		width = rect[1][0]
		height = rect[1][1]

		if width> width_g*0.9 or height> height_g*0.9:
			continue
		if width > height and width / height < 1.2:
			continue
		if width < height and height / width < 1.2:
			continue
		if width<10 or height<10:
			continue
		# 排除1号最大的目标之后的第二大目标
		if (width > max_area and i != area1):
			max_area=width
			area2=i
	max_area = 0
	width = 0
	height = 0

	# 3 获取第三大的目标框
	for i in range(len(contours)):
		areax = cv2.contourArea(contours[i])
		if areax <2000or  areax >8000:
			continue
		rect = cv2.minAreaRect(contours[i])
		width = rect[1][0]
		height = rect[1][1]

		if width> width_g*0.9 or height> height_g*0.9:
			continue
		if width > height and width / height < 1.2:
			continue
		if width < height and height / width < 1.2:
			continue
		if width<10 or height<10:
			continue
		# 排除1号和2号的目标之后的第三大目标
		if (width > max_area and i != area1 and i != area2):
			max_area=width
			area3=i
	max_area = 0
	width = 0
	height = 0

	# 4 获取第四大的目标框
	for i in range(len(contours)):
		areax = cv2.contourArea(contours[i])
		if  areax <2000or  areax >8000:
			continue
		rect = cv2.minAreaRect(contours[i])
		width = rect[1][0]
		height = rect[1][1]


		if width> width_g*0.9 or height> height_g*0.9:
			continue
		if width > height and width / height < 1.2:
			continue
		if width < height and height / width < 1.2:
			continue
		if width<10 or height<10:
			continue
		# 排除1号和2号和3号的目标之后的第四大目标
		if (width > max_area and i != area1 and i != area2 and i!=area3):
			max_area=width
			area4=i

	min_x = 10000
	min_y = 10000
	max_y = 0;
	# 根据前四个目标框，去除大部分的背景数据
	num = 1
	for i in range(len(contours)):
		# 筛掉面积过小的轮廓
		area = cv2.contourArea(contours[i])
		# 获取四个目标框的数据
		if i==area1 or i==area2 or i==area3 or  i==area4:

			# 找到包含轮廓的最小矩形框
			rect = cv2.minAreaRect(contours[i])
			# 计算矩形框的四个顶点坐标
			box = cv2.boxPoints(rect)
			box = np.int0(box)

			for i in range(3):
				if np.abs(box[i][1]-box[i+1][1]) <30:
					width = np.abs(box[i][0] - box[i+1][0])
				if np.abs(box[i][0]-box[i+1][0]) <30:
					height = np.abs(box[i][1] - box[i+1][1])
			for i in range(4):
				if box[i][0]<0 or box[i][1]<0:
					continue
				if min_x > box[i][0]:
					min_x = box[i][0]
				if min_y > box[i][1]:
					min_y = box[i][1]
				if max_y <box[i][1]:
					max_y = box[i][1]

			# 绘制轮廓
			import copy
			tmp_img = copy.copy(cropped_img)
			cv2.drawContours(cropped_img, [box], 0, (0, 255, 0), 5)
			Xs = [i[0] for i in box]
			Ys = [i[1] for i in box]
			x1 = min(Xs)
			x2 = max(Xs)
			y1 = min(Ys)
			y2 = max(Ys)
			hight_t = y2 - y1
			width_t = x2 - x1
			cropImg = tmp_img[y1:y1 + hight_t, x1:x1 + width_t]
			cv2.imwrite("./data/{}.png".format(num).format(num), cropImg)
			num += 1

	height_d, width_d = dilated.shape
	# 根据前四个目标框坐标信息，将非目标框内的数据设置为0
	for y in range(height_d):
		for x in range(width_d):
			# 根据所有目标的坐标数据得到的最大y值和最小y值，去掉目标以上和目标一下的数据
			if y < min_y or y > max_y:
				dilated[y, x] = 0

			# 根据先验，去掉边缘数据
			if x > width_d*0.85:
				dilated[y, x] = 0
			if  y > height_d *0.8:
				dilated[y, x] = 0
	# ***************************第二次检测为了获取更清楚的目标位置******************
	# 对dilated图片进行膨胀得到dilated_test，使得目标形成图片中最大的连通区域
	dilated_test = cv2.dilate(dilated.copy(), None, iterations=16)
	# 初始化参数
	min_x = 10000
	min_y = 10000
	max_y = 0;
	#第二次检测dilated_test分割部分，找到最大的检测框作为目标检测框
	contours_test, hierarchy_test = cv2.findContours(dilated_test, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
	for i in range(len(contours_test)):
		areax_test = cv2.contourArea(contours_test[i])
		# 由于膨胀之后dilated_test的检测，areax_test的值会比较大，下面的参数可以设置相对大一点，目前是4000
		if areax_test < 4000:
			continue
		print("areax:", areax_test)
		# 找到包含轮廓的最小矩形框
		rect_test = cv2.minAreaRect(contours_test[i])
		# 计算矩形框的四个顶点坐标
		box_test = cv2.boxPoints(rect_test)
		box_test = np.int0(box_test)
		# 获取目标框的长款
		width_test = rect_test[1][0]
		height_test = rect_test[1][1]
		# 判断目标长款，去除背景误检
		if width_test> width_g*0.9 or height_test> height_g*0.9:
			continue

		# 背景数据基本上都是长条形的数据，目标数据基本上是长宽比在3以内，根据先验去除背景数据
		if width_test > height_test and width_test / height_test >3:
			continue
		if width_test < height_test and height_test / width_test > 3:
			continue

		# 查找目标框的坐标极值
		for i in range(4):
			print("x", box_test[i][0])
			print("y", box_test[i][0])
			if min_x > box_test[i][0]:
				min_x = box_test[i][0]
			if min_y > box_test[i][1]:
				min_y = box_test[i][1]
			if max_y < box_test[i][1]:
				max_y = box_test[i][1]
	cv2.drawContours(dilated_test, [box_test], 0, (255, 255, 255), 5)

	# 对数据进行清理，根据目标框的值，去除背景数据，获取更干净的目标数据，将背景数据像素值设置为0
	for y in range(height_d):
		for x in range(width_d):
			# 对目标上下的数据进行清除
			if y < min_y or y > max_y:
				dilated[y, x] = 0
			# 对目标左右的数据进行清除
			if x > width_d*0.85 or x< min_x:
				dilated[y, x] = 0
			# 根据先验去除背景数据
			if  y > height_d *0.8:
				dilated[y, x] = 0
	# dilated = cv2.erode(dilated, kernel, iterations=8)
	# dilated=cv2.dilate(dilated, kernel, iterations=8)

	# 腐蚀操作让图片dilated恢复到膨胀之前的效果，纹理更清晰
	dilated = cv2.erode(dilated, None, iterations=5)
	# dilated = cv2.dilate(dilated, None, iterations=10)
	import pytesseract


   # 模版匹配操作*********************************
	# Load the image and the template
	import os
	template_list = os.listdir("./testData/numbers")
	data_list = os.listdir("./data")

	# Store the file names in a list
	file_names = []
	for file_name in template_list:
		file_names.append("./testData/numbers/" + file_name)

	origin_files = []
	for file_name in data_list:
		origin_files.append("./data/" + file_name)

	text = []
	print("begin))))))))))))))))))))))))")
	print(origin_files)
	print(file_names)
	for data in origin_files:
		print("ppppppppppppppppppppppppppp")
		template_map = {}
		for template_file in file_names:
			print("ok))))))))))))))))))))0")
			img_tmp = cv2.imread(data)
			template = cv2.imread(template_file)
			print("read end))))))))))))))))0")

			# Convert the images to grayscale
			img_gray = cv2.cvtColor(img_tmp, cv2.COLOR_BGR2GRAY)
			template_gray = cv2.cvtColor(template, cv2.COLOR_BGR2GRAY)

			# Apply erosion to the template
			kernel = np.ones((5, 5), np.uint8)
			template_eroded = cv2.erode(template_gray, kernel, iterations=1)

			print("begin template )))))))))))))))))))))))")
			# Perform template matching
			try:
				res = cv2.matchTemplate(img_gray, template_eroded, cv2.TM_CCOEFF_NORMED)
			except Exception as ex:
				continue
			print("end templat))))))))))))))))))))))0")

			sum_num = 0
			for data_list in res:
				sum_num += sum(data_list)

			template_map[template_file] = sum_num
			print("end))))))))))))))))))))))))")

		max_tmplate_num = 0
		tmp_file = ""
		# 遍历获取匹配程度最高的
		for key,value in template_map.items():
			if value > max_tmplate_num:
				tmp_file = key
		text.append(tmp_file)

	results = text

	# 打印结果--可以在命令行查看
	print("*************results:", results)

	time = ""
	for word in text:
		time += os.path.basename(word).split(".")[0]
		if len(time) == 2:
			time += ":"

	# 在一行两列的图像显示中，第一个显示原图像
	plt.subplot(1, 2, 1)
	plt.imshow(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))
	plt.title('Image')
	# 在一行两列的图像显示中，第二个显示第一次检测的图像cropped_img，也可以显示第二次检测后的图像dilated
	plt.subplot(1, 2, 2)
	plt.imshow(cv2.cvtColor(cropped_img, cv2.COLOR_BGR2RGB))
	plt.title(f"Time: {time}")
	plt.show()

# try:
# 	timeGet()
# except Exception as e:
# 	pass