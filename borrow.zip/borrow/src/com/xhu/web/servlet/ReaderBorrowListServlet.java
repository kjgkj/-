package com.xhu.web.servlet;

import com.xhu.web.po.Borrow;
import com.xhu.web.service.BorrowService;
import com.xhu.web.service.BorrowServiceImpl;
import com.xhu.web.service.ReaderService;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.util.List;

@WebServlet("/ReaderBorrowListServlet")
public class ReaderBorrowListServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request,response);

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        HttpSession session=request.getSession();
        String ReaderID=(String) session.getAttribute("ReaderID");

        BorrowService service=new BorrowServiceImpl();
        List<Borrow> borrowList2=service.BorrowBook(ReaderID);
        request.setAttribute("borrowlist2",borrowList2);
        request.getRequestDispatcher("ReaderBorrowList.jsp").forward(request,response);
    }
}
