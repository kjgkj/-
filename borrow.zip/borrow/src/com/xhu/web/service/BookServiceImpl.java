package com.xhu.web.service;

import com.xhu.web.dao.BookDao;
import com.xhu.web.dao.BookDaoImpl;
import com.xhu.web.dao.BorrowDao;
import com.xhu.web.dao.BorrowDaoImpl;
import com.xhu.web.po.Book;
import com.xhu.web.po.Borrow;

import java.util.ArrayList;
import java.util.List;

public class BookServiceImpl implements BookService{
    private BookDao dao=new BookDaoImpl();

    @Override
    public List<Book> ListBook() {
        List<Book> books=new ArrayList<>();
        books=dao.selectAll();
        return books;
    }

    @Override
    public void AddBook(Book book) {
        dao.insert(book);
    }

    @Override
    public void DeleteBook(String BookID) {
        dao.delete(BookID);
    }

    @Override
    public void UpdateBook(Book book) {
        dao.update( book);
    }

    @Override
    public Book SelectBook(String BookID) {
        Book book=new Book();
        book=dao.selectByID(BookID);
        return book;
    }



}
