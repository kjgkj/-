package com.xhu.web.servlet;

import com.xhu.web.dao.BookDao;
import com.xhu.web.dao.BookDaoImpl;
import com.xhu.web.po.Book;
import com.xhu.web.service.BookService;
import com.xhu.web.service.BookServiceImpl;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet("/AdminAddServlet")
public class AdminAddServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
       doPost(request,response);

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        String Bookid=request.getParameter("id");
        String Bookname=request.getParameter("name");
        String Bookauthor=request.getParameter("author");
        String Booktype=request.getParameter("type");
        String publisherid=request.getParameter("pid");
        int Bookprice=Integer.parseInt(request.getParameter("price"));
        int Booknum=Integer.parseInt(request.getParameter("num"));
        int Bookstock=Integer.parseInt(request.getParameter("stock"));
        Book book=new Book(Bookid,Bookname,Booktype,Bookauthor,publisherid,Bookprice,Booknum,Bookstock);
        BookService service=new BookServiceImpl();
        service.AddBook(book);
        response.sendRedirect(request.getContextPath()+"/AdminListServlet");

    }
}
