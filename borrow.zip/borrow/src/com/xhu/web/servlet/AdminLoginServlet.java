package com.xhu.web.servlet;

import com.xhu.web.po.Admin;
import com.xhu.web.service.AdminService;
import com.xhu.web.service.AdminServiceImpl;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet(name = "AdminLoginServlet", value = "/AdminLoginServlet")
public class AdminLoginServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request,response);

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String AdminID=request.getParameter("AdminID");
        String AdminPassword=request.getParameter("AdminPassword");
        AdminService service=new AdminServiceImpl();
        Admin admin=service.Adminquerypwd(AdminID);
        if(AdminPassword.equals(admin.getAdminPassowrd())){
            request.getRequestDispatcher("Admin.jsp").forward(request,response);
        }
        else{

            response.sendRedirect("error.html");
        }

    }
}
