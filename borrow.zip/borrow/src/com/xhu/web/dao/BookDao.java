package com.xhu.web.dao;

import com.xhu.web.po.Book;

import java.util.List;

public interface BookDao {
    void insert(Book book);
    void update(Book book);
    void delete(String BookID);
    List<Book> selectAll( );
    Book selectByID(String BookID);


}
