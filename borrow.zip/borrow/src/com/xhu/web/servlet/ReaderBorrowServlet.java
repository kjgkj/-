package com.xhu.web.servlet;

import com.xhu.web.po.Book;
import com.xhu.web.po.Borrow;
import com.xhu.web.service.BookService;
import com.xhu.web.service.BookServiceImpl;
import com.xhu.web.service.BorrowService;
import com.xhu.web.service.BorrowServiceImpl;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.sql.Date;

@WebServlet("/ReaderBorrowServlet")
public class ReaderBorrowServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request,response);

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String ReaderID=request.getParameter("ReaderID");
        String BookID=request.getParameter("BookID");
        Date BorrowTime= Date.valueOf(request.getParameter("borrowtime"));
        Date ReturnTime=Date.valueOf(request.getParameter("returntime"));
        BorrowService service=new BorrowServiceImpl();
        Borrow borrow=new Borrow(ReaderID,BookID,BorrowTime,ReturnTime);
        service.ReaderBorrowBook(borrow);
        response.sendRedirect(request.getContextPath()+"/ReaderListServlet");

    }
}
