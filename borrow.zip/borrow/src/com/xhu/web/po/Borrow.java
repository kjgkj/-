package com.xhu.web.po;

import java.sql.Date;

public class Borrow {
    private String ReaderID;
    private String BookID;
    private Date BorrowTime;
    private Date ReturnTime;

    public Borrow() {
        super();
    }

    public Borrow(String readerID, String bookID, Date borrowTime, Date returnTime) {
        ReaderID = readerID;
        BookID = bookID;
        BorrowTime = borrowTime;
        ReturnTime = returnTime;
    }

    public String getReaderID() {
        return ReaderID;
    }

    public void setReaderID(String readerID) {
        ReaderID = readerID;
    }

    public String getBookID() {
        return BookID;
    }

    public void setBookID(String bookID) {
        BookID = bookID;
    }

    public Date getBorrowTime() {
        return BorrowTime;
    }

    public void setBorrowTime(Date borrowTime) {
        BorrowTime = borrowTime;
    }

    public Date getReturnTime() {
        return ReturnTime;
    }

    public void setReturnTime(Date returnTime) {
        ReturnTime = returnTime;
    }

    @Override
    public String toString() {
        return "Borrow{" +
                "ReaderID='" + ReaderID + '\'' +
                ", BookID='" + BookID + '\'' +
                ", BorrowTime=" + BorrowTime +
                ", ReturnTime=" + ReturnTime +
                '}';
    }
}
