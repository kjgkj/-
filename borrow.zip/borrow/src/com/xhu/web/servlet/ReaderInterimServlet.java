package com.xhu.web.servlet;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet("/ReaderInterimServlet")
public class ReaderInterimServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request,response);

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        String BookID=request.getParameter("BookID");
        request.setAttribute("BookID",BookID);
        request.getRequestDispatcher("ReaderBorrow.jsp").forward(request,response);

    }
}
