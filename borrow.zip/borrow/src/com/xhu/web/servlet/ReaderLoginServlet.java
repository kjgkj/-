package com.xhu.web.servlet;

import com.xhu.web.po.Reader;
import com.xhu.web.service.ReaderService;
import com.xhu.web.service.ReaderServiceImpl;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet("/ReaderLoginServlet")
public class ReaderLoginServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request,response);

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        String ReaderID=request.getParameter("ReaderID");
        String ReaderPassword=request.getParameter("password");
        ReaderService service=new ReaderServiceImpl();

        Reader reader=service.querypwd(ReaderID);

        request.setAttribute("ReaderName",reader.getReaderName());

        HttpSession session=request.getSession();
        session.setAttribute("ReaderID",ReaderID);


        if(ReaderID.equals(reader.getReaderID())&&ReaderPassword.equals(reader.getReaderPassword())){
            request.getRequestDispatcher("Reader.jsp").forward(request,response);
        }
        else {
            response.sendRedirect("error.html");
        }


    }
}
