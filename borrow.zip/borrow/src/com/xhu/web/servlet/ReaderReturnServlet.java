package com.xhu.web.servlet;

import com.xhu.web.service.BorrowService;
import com.xhu.web.service.BorrowServiceImpl;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet( "/ReaderReturnServlet")
public class ReaderReturnServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request,response);

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        String BookID=request.getParameter("BookID");
        BorrowService service=new BorrowServiceImpl();
        service.ReturnBook(BookID);
        response.sendRedirect(request.getContextPath()+"/ReaderBorrowListServlet");

    }
}
