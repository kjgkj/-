package com.xhu.web.service;

import com.xhu.web.po.Borrow;

import java.util.List;

public interface BorrowService {
    void ReaderBorrowBook(Borrow borrow);
    List<Borrow> BorrowBook(String ReaderID);
    void ReturnBook(String BookID);
}
