package com.xhu.web.test;

import com.xhu.web.dao.*;
import com.xhu.web.po.Admin;
import com.xhu.web.po.Book;
import com.xhu.web.po.Borrow;
import com.xhu.web.po.Reader;
import com.xhu.web.service.BorrowService;
import com.xhu.web.service.BorrowServiceImpl;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.util.List;

public class ImplTest {
    private BookDao dao=new BookDaoImpl();
    @Before
    public void setUp() {
        dao=new BookDaoImpl();
        System.out.println("setUp is executed");
    }
    @After
    public void  setDown() {
        dao=null;
        System.out.println("setDown is executed");
    }
    @Test
    public void TestAdd(){
        Book book=new Book("r0489","Test","test","cy","p07",999,20,20);
        dao.insert(book);
        System.out.println("add success");
        System.out.println(book.getAuthor());

    }
    @Test
    public void TsetUpdate(){
        Book book=new Book("3","李四","sf","fe","ef,",66,66,66);
        dao.update(book);
        System.out.println(book.getBookType());
    }
    @Test
    public void TestDelete(){

        dao.delete("r014");
    }
    @Test
    public void TestselectAll(){

        List<Book> book = dao.selectAll();
        for(Book c:book){
            System.out.println(c);
        }
    }
    @Test
    public void TestselectByID(){
        Book book=dao.selectByID("b010");
        System.out.println(book);
    }
    @Test
    public void Testselectborrow(){
        BorrowDao dao1=new BorrowDaoImpl();
        List<Borrow> borrowList=dao1.selectAllBorrow();
        for(Borrow c:borrowList){
            System.out.println(c);
        }
    }
    @Test
    public void Testborrrow(){
        Borrow borrow=new Borrow("r001","b011",null,null);
        BorrowDao dao1=new BorrowDaoImpl();
        dao1.borrowbook(borrow);
    }
    @Test
    public void Tsetquerypwd(){
        ReaderDao dao2=new ReaderDaoImpl();
        Reader reader=dao2.selectpwd("r001");
        System.out.println(reader);
    }
    @Test
    public void TestQueryReaderBorrow(){
       BorrowDao dao1=new BorrowDaoImpl();
        List<Borrow> borrows=dao1.selectReaderBorrow("r001");
        for (Borrow c:borrows){
            System.out.println(c);
        }
    }
    @Test
    public void testService(){
        BorrowService service=new BorrowServiceImpl();
        List<Borrow> borrows=service.BorrowBook("r001");
        System.out.println(borrows);
    }
    @Test
    public void testreturnbook(){
        BorrowService service=new BorrowServiceImpl();
        service.ReturnBook("b001");
    }
    @Test
    public void testAdminLOgin(){
        AdminDao dao2=new AdminDaoImpl();
        Admin admin=dao2.selectAdminByID("admin");
        System.out.println(admin);
    }

}
