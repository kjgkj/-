package com.xhu.web.dao;

import com.xhu.web.po.Reader;

public interface ReaderDao {
    Reader selectpwd(String BookID);

}
