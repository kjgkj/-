package com.xhu.web.po;

public class Reader {
    private String ReaderID;
    private String ReaderName;
    private String ReaderPassword;
    private String Sex;
    private String Subject;
    private int BorrowNum;

    public Reader() {
        super();
    }

    public String getReaderID() {
        return ReaderID;
    }

    public void setReaderID(String readerID) {
        ReaderID = readerID;
    }

    public String getReaderName() {
        return ReaderName;
    }

    public void setReaderName(String readerName) {
        ReaderName = readerName;
    }

    public String getReaderPassword() {
        return ReaderPassword;
    }

    public void setReaderPassword(String readerPassword) {
        ReaderPassword = readerPassword;
    }

    public String getSex() {
        return Sex;
    }

    public void setSex(String sex) {
        Sex = sex;
    }

    public String getSubject() {
        return Subject;
    }

    public void setSubject(String subject) {
        Subject = subject;
    }

    public int getBorrowNum() {
        return BorrowNum;
    }

    public void setBorrowNum(int borrowNum) {
        BorrowNum = borrowNum;
    }

    @Override
    public String toString() {
        return "Reader{" +
                "ReaderID='" + ReaderID + '\'' +
                ", ReaderName='" + ReaderName + '\'' +
                ", ReaderPassword='" + ReaderPassword + '\'' +
                ", Sex='" + Sex + '\'' +
                ", Subject='" + Subject + '\'' +
                ", BorrowNum=" + BorrowNum +
                '}';
    }
}
