package com.xhu.web.po;

public class Book {
    private String BookID;
    private String BookName;
    private String BookType;
    private String Author;
    private String PublisherID;
    private int Price;
    private int BookSum;
    private int Stock;
    public Book() {
        super();
    }

    public Book(String bookID, String bookName, String bookType, String author, String publisherID, int price, int bookSum, int stock) {
        BookID = bookID;
        BookName = bookName;
        BookType = bookType;
        Author = author;
        PublisherID = publisherID;
        Price = price;
        BookSum = bookSum;
        Stock = stock;
    }

    public String getBookID() {
        return BookID;
    }

    public void setBookID(String bookID) {
        BookID = bookID;
    }

    public String getBookName() {
        return BookName;
    }

    public void setBookName(String bookName) {
        BookName = bookName;
    }

    public String getBookType() {
        return BookType;
    }

    public void setBookType(String bookType) {
        BookType = bookType;
    }

    public String getAuthor() {
        return Author;
    }

    public void setAuthor(String author) {
        Author = author;
    }

    public String getPublisherID() {
        return PublisherID;
    }

    public void setPublisherID(String publisherID) {
        PublisherID = publisherID;
    }

    public int getPrice() {
        return Price;
    }

    public void setPrice(int price) {
        Price = price;
    }

    public int getBookSum() {
        return BookSum;
    }

    public void setBookSum(int bookSum) {
        BookSum = bookSum;
    }

    public int getStock() {
        return Stock;
    }

    public void setStock(int stock) {
        Stock = stock;
    }

    @Override
    public String toString() {
        return "Book{" +
                "BookID='" + BookID + '\'' +
                ", BookName='" + BookName + '\'' +
                ", BookType='" + BookType + '\'' +
                ", Author='" + Author + '\'' +
                ", PublishID=" + PublisherID +
                ", Price=" + Price +
                ", BookSum=" + BookSum +
                ", Stock=" + Stock +
                '}';
    }
}
