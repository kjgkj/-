package com.xhu.web.servlet;

import com.xhu.web.dao.BookDao;
import com.xhu.web.dao.BookDaoImpl;
import com.xhu.web.po.Book;
import com.xhu.web.service.BookService;
import com.xhu.web.service.BookServiceImpl;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.util.List;

@WebServlet("/AdminListServlet")
public class AdminListServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request,response);

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        BookService service=new BookServiceImpl();
        List<Book> bookList=service.ListBook();
        request.setAttribute("booklist",bookList);
        request.getRequestDispatcher("AdminList.jsp").forward(request,response);
    }
}
