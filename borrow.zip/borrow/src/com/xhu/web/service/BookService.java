package com.xhu.web.service;

import com.xhu.web.po.Book;
import com.xhu.web.po.Borrow;

import java.util.List;

public interface BookService {
    List<Book> ListBook();
    void AddBook(Book book);
    void DeleteBook(String BookID);
    void UpdateBook(Book book);
    Book SelectBook(String BookID);


}
