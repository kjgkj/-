package com.xhu.web.dao;

import com.xhu.web.po.Admin;

public interface AdminDao {
    public Admin selectAdminByID(String AdminID);

}
