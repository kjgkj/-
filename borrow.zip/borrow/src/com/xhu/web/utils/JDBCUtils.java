package com.xhu.web.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class JDBCUtils {
    private static final String URL = "jdbc:mysql://localhost:3306/library";
    private static final String USERNAME = "root";
    private static final String PASSWORD = "111111";

    /*
     * 获取数据库连接
     */
    public static Connection getConnection() {
        Connection conn = null;
        try {
            //加载驱动
            Class.forName("com.mysql.cj.jdbc.Driver");
            //获取连接对象
            conn = DriverManager.getConnection(URL, USERNAME, PASSWORD);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return conn;
    }

    /*
     * 关闭数据库连接
     */
    public static void close(Connection conn, Statement stmt, ResultSet rs) {
        try {
            if (rs != null) {
                rs.close();
            }
            if (stmt != null) {
                stmt.close();
            }
            if (conn != null) {
                conn.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /*
     * 执行查询操作
     */
    public static ResultSet executeQuery(String sql) {
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;
        try {
            //获取连接对象
            conn = getConnection();
            //创建Statement对象
            stmt = conn.createStatement();
            //执行查询语句，并返回结果集对象
            rs = stmt.executeQuery(sql);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return rs;
    }

    /*
     * 执行更新操作
     */
    public static int executeUpdate(String sql) {
        Connection conn = null;
        Statement stmt = null;
        int result = 0;
        try {
            //获取连接对象
            conn = getConnection();
            //创建Statement对象
            stmt = conn.createStatement();
            //执行更新语句，并返回受影响行数
            result = stmt.executeUpdate(sql);
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            //关闭连接、Statement对象
            close(conn, stmt, null);
        }
        return result;
    }
}
